# 输出产物清单

本文档定义 testcase-generator 在各阶段可能产生的标准产物，用于补充主入口 `SKILL.md`，避免将详细产物协议全部堆叠在入口文件中。

## 使用原则

- 仅在用户要求完整流程、正式交付物或高风险模块测试设计时输出全部阶段产物。
- 若用户只需要快速测试点、边界场景或回归建议，可跳过部分阶段，只输出最小必要结果。
- 所有阶段产物都应尽量保持可追溯：说明来源、依赖关系、假设项与未确认点。
- 若输入信息不足，不要伪造完整产物，优先输出缺口清单和降级版本。

## 覆盖的核心能力

本产物清单对应本技能声明的全部 7 项核心能力，按阶段承接：

- **输入质量预处理**：Phase 0 产物（`00_input_validation_report.md`、`00_normalized_input.md`）。
- **可测试需求抽取**：Phase 1 产物（`01_requirements_summary.md`、`02_testable_requirements.md`）。
- **代码与接口契约辅助分析**：Phase 2 产物（`01_code_structure.md`、`02_data_flow_analysis.md`、`03_defect_radar.md`）。
- **领域模型与状态模型构建**：Phase 3 产物（`01_business_domain_model.md`、`02_state_machine_spec.md`、`04_event_storming_model.md`）。
- **MBT 导向测试设计**：Phase 4 产物（`01_test_model_specification.md`、`02_state_transition_graph.md`、`03_coverage_criteria.md`、`04_mutation_testing_strategy.md`）。
- **结构化测试用例生成**：Phase 5 产物（`01_testcase_collection.md`、`02_test_suite_summary.md`、`04_chaos_engineering_scenarios.md`、`05_test_data_strategy.md`）。
- **追溯矩阵与质量门禁**：Phase 5 + 全局产物（`03_traceability_matrix.md`、`quality_report.md`）。

## 能力标记

本 Skill 的分发审计会检查以下能力是否仍可被入口或资源文件发现：

- 阶段 0 输入预处理
- 反馈闭环
- 配置 Schema 校验
- 混沌工程场景
- 测试数据工厂
- 变异测试策略

## 阶段总览

| 阶段 | 名称 | 目标 | 常见产物 |
|------|------|------|---------|
| Phase 0 | 输入预处理 | 验证、规范化、识别缺口 | 输入质量报告、规范化输入、增强建议 |
| Phase 1 | 需求分析 | 提取可测试需求与边界 | 需求摘要、测试需求清单、边界条件 |
| Phase 2 | 代码分析 | 理解实现逻辑与风险路径 | 结构分析、数据流分析、缺陷雷达 |
| Phase 3 | 领域建模 | 形成业务实体、状态与参数模型 | 领域模型、状态机规格、参数空间 |
| Phase 4 | MBT 设计 | 将领域模型转为测试模型与覆盖准则 | 测试模型规格、状态图、覆盖准则 |
| Phase 5 | 用例生成 | 生成结构化测试用例与追溯关系 | 用例集、摘要、追溯矩阵 |

## Phase 0：输入预处理

适用场景：
- 输入格式混杂
- 文档质量未知
- 需求内容模糊或缺失明显
- 用户上传本地文件或长文档

建议产物：
- `00_input_validation_report.md`：输入质量评估、格式识别、主要风险
- `00_normalized_input.md`：规范化后的正文内容与结构整理
- `00_enhancement_suggestions.md`：补充信息建议、歧义点、缺失项
- `00_blockers_and_assumptions.md`：输入缺陷阻断项、强假设项、继续生成的前提条件

阻断规则：
- 若发现乱码、字段缺失、状态机不闭合、关键规则互相冲突、验收标准不可判定等问题，必须在 `00_blockers_and_assumptions.md` 中显式记录。
- 若阻断项会直接影响正式测试用例的正确性，不得跳过说明后直接输出“正式交付物”，只能降级为草稿、风险清单或带假设的结果。
- 对所有继续推进所依赖的推断，必须标记为“假设”并说明依据。

## Phase 1：需求分析


适用场景：
- 用户提供 PRD、需求文档、用户故事、功能描述
- 需要从业务目标拆解测试范围

建议产物：
- `01_requirements_summary.md`：需求摘要、功能分解、测试目标
- `02_testable_requirements.md`：可测试需求条目化清单
- `03_boundary_conditions.md`：边界条件、等价类、异常情况
- `04_nfr_and_impact_analysis.md`：非功能需求、影响分析、关键用户旅程

## Phase 2：代码分析

适用场景：
- 用户提供代码、接口实现、服务逻辑、API 定义
- 需要补足隐藏分支、异常处理、契约风险

建议产物：
- `00_incremental_scope.md`：增量代码行扫描、PRD 符合性、潜在 bug 信号（增量模式适用）
- `01_code_structure.md`：模块结构、调用关系、主要职责
- `02_data_flow_analysis.md`：数据流、控制流、关键依赖
- `03_defect_radar.md`：潜在缺陷点、脆弱逻辑、风险判断
- `04_concurrency_analysis.md`：并发、竞态、锁或异步风险（如适用）
- `05_contract_test_derivation.md`：接口契约测试推导（如适用）

## Phase 3：领域建模

适用场景：
- 存在状态流转、复杂规则、角色权限、生命周期管理
- 需要为 MBT 建立稳定抽象模型

建议产物：
- `01_business_domain_model.md`：业务实体、关系与职责
- `02_state_machine_spec.md`：状态、事件、转换条件、非法路径
- `03_test_parameter_space.md`：参数空间与约束定义
- `04_event_storming_model.md`：关键事件、命令、聚合与边界上下文（如适用）
- `05_temporal_constraints.md`：时序约束、超时、顺序依赖、集成点（如适用）

## Phase 4：MBT 设计

适用场景：
- 用户需要基于模型生成测试
- 系统状态复杂，单靠手工列举容易漏测

建议产物：
- `01_test_model_specification.md`：测试模型结构与定义
- `02_state_transition_graph.md`：状态转换图或 Mermaid 图
- `03_coverage_criteria.md`：覆盖准则、优先级策略、最小覆盖集
- `04_mutation_testing_strategy.md`：变异测试策略（如适用）
- `05_error_guessing_checklist.md`：错误猜测法检查清单（如适用）

## Phase 5：用例生成

适用场景：
- 需要正式测试用例交付物
- 需要回归测试集、接口测试集或完整追溯矩阵

建议产物：
- `01_testcase_collection.md`：完整测试用例集合
- `02_test_suite_summary.md`：规模、覆盖、优先级与风险摘要
- `03_traceability_matrix.md`：需求、模型、场景、用例之间的映射
- `04_chaos_engineering_scenarios.md`：混沌工程场景、故障注入、韧性验证（如适用）
- `05_test_data_strategy.md`：测试数据工厂、样例数据、清洗策略（如适用）
- `quality_report.md`：全流水线质量评分汇总，横跨 Phase 0-5 的全局产物（模板见 `../../../docs/quality/quality-gates.md`（项目仓库文档，不在本包内））

## 交付深度建议

### 轻量交付
适用：
- 快速讨论
- 需求评审前期
- 只要测试点或补充清单

建议输出：
- 测试点清单
- 边界条件列表
- 风险与缺口摘要

### 标准交付
适用：
- 常规功能模块
- Sprint 级测试设计
- API / 页面 / 业务流程测试

建议输出：
- 可测试需求清单
- 结构化测试用例
- 边界 + 异常 + 回归场景
- 简版追溯关系

### 完整交付
适用：
- 高风险流程
- 复杂状态流转
- 金融、支付、审批、订单、合规类系统

建议输出：
- 分阶段分析产物
- 领域/状态模型
- MBT 设计结果
- 全量测试用例
- 追溯矩阵
- 质量总结
